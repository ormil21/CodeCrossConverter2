// CONVERSION ERROR: Failed to convert code using AI: Error code: 429 - {'error': {'message': 'You exceeded your current quota, please check your plan and billing details. For more information on this error, read the docs: https://platform.openai.com/docs/guides/error-codes/api-errors.', 'type': 'insufficient_quota', 'param': None, 'code': 'insufficient_quota'}}

package com.example.myapp.model;

import java.util.List;
import java.util.ArrayList;

public class UserProfile {
    private String userId;
    private String username;
    private String email;
    private List<String> interests;
    private boolean isActive;
    
    public UserProfile(String userId, String username, String email) {
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.interests = new ArrayList<>();
        this.isActive = true;
    }
    
    // Getter methods
    public String getUserId() {
        return userId;
    }
    
    public String getUsername() {
        return username;
    }
    
    public String getEmail() {
        return email;
    }
    
    public List<String> getInterests() {
        return interests;
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    // Setter methods
    public void setUsername(String username) {
        this.username = username;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public void setActive(boolean active) {
        this.isActive = active;
    }
    
    // Utility methods
    public void addInterest(String interest) {
        if (!interests.contains(interest)) {
            interests.add(interest);
        }
    }
    
    public void removeInterest(String interest) {
        interests.remove(interest);
    }
    
    public boolean hasInterest(String interest) {
        return interests.contains(interest);
    }
    
    @Override
    public String toString() {
        return "UserProfile{" +
                "userId='" + userId + '\'' +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", interests=" + interests +
                ", isActive=" + isActive +
                '}';
    }
}